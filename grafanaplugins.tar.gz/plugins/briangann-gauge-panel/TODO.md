

TODO:

* Animation options
 * Split needle animation and value transition settings
 * Add selector for animation types (currently elastic and quadin)
 * Add speed option (currently 500ms)
* Add trending indicator (arrow up/down based on last value and current value)
* Add metric label option (display name of metric/alias inside face of gauge)
* More needle shape selections (add chooser)
* Add text location below value in gauge to display mapped value to text/range to text
